import numpy as np
from tqdm import tqdm
import joblib
from typing import List, Tuple, Dict
import json
import os

class CustomNeuralNetwork:
    def __init__(self, layers: List[int], learning_rate: float = 0.01):
        self.layers = layers
        self.learning_rate = learning_rate
        self.weights = []
        self.biases = []
        self.history = []
        
        # Initialize weights and biases with improved Xavier initialization
        for i in range(len(layers) - 1):
            scale = np.sqrt(2.0 / (layers[i] + layers[i + 1]))
            self.weights.append(np.random.randn(layers[i], layers[i + 1]) * scale)
            self.biases.append(np.zeros((1, layers[i + 1])))
    
    def activation(self, x: np.ndarray, derivative: bool = False) -> np.ndarray:
        """Advanced activation function using LeakyReLU"""
        alpha = 0.01
        if derivative:
            return np.where(x > 0, 1, alpha)
        return np.where(x > 0, x, alpha * x)
    
    def softmax(self, x: np.ndarray) -> np.ndarray:
        """Stable softmax implementation"""
        exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exp_x / np.sum(exp_x, axis=1, keepdims=True)
    
    def forward_propagation(self, X: np.ndarray) -> List[np.ndarray]:
        """Forward propagation with layer normalization"""
        activations = [X]
        
        for i in range(len(self.weights)):
            net = np.dot(activations[-1], self.weights[i]) + self.biases[i]
            
            # Layer normalization
            mean = np.mean(net, axis=1, keepdims=True)
            std = np.std(net, axis=1, keepdims=True) + 1e-8
            net = (net - mean) / std
            
            # Apply activation function
            if i == len(self.weights) - 1:
                activation = self.softmax(net)
            else:
                activation = self.activation(net)
            
            activations.append(activation)
        
        return activations
    
    def backward_propagation(self, X: np.ndarray, y: np.ndarray, activations: List[np.ndarray]) -> Tuple[List[np.ndarray], List[np.ndarray]]:
        """Backward propagation with improved gradient computation"""
        m = X.shape[0]
        delta = activations[-1] - y
        
        grad_weights = []
        grad_biases = []
        
        for i in range(len(self.weights) - 1, -1, -1):
            grad_w = np.dot(activations[i].T, delta) / m
            grad_b = np.sum(delta, axis=0, keepdims=True) / m
            
            if i > 0:
                delta = np.dot(delta, self.weights[i].T) * self.activation(activations[i], derivative=True)
            
            grad_weights.insert(0, grad_w)
            grad_biases.insert(0, grad_b)
        
        return grad_weights, grad_biases
    
    def train(self, X: np.ndarray, y: np.ndarray, epochs: int, batch_size: int = 32, validation_split: float = 0.2) -> Dict:
        """Train the neural network with mini-batch gradient descent and validation"""
        m = X.shape[0]
        val_size = int(m * validation_split)
        train_size = m - val_size
        
        # Split data into training and validation sets
        indices = np.random.permutation(m)
        X_train = X[indices[:train_size]]
        y_train = y[indices[:train_size]]
        X_val = X[indices[train_size:]]
        y_val = y[indices[train_size:]]
        
        history = {
            'train_loss': [],
            'train_accuracy': [],
            'val_loss': [],
            'val_accuracy': []
        }
        
        for epoch in tqdm(range(epochs), desc="Training"):
            # Mini-batch training
            for i in range(0, train_size, batch_size):
                batch_X = X_train[i:i + batch_size]
                batch_y = y_train[i:i + batch_size]
                
                # Forward propagation
                activations = self.forward_propagation(batch_X)
                
                # Backward propagation
                grad_weights, grad_biases = self.backward_propagation(batch_X, batch_y, activations)
                
                # Update weights and biases with momentum
                for j in range(len(self.weights)):
                    self.weights[j] -= self.learning_rate * grad_weights[j]
                    self.biases[j] -= self.learning_rate * grad_biases[j]
            
            # Calculate metrics
            train_pred = self.predict(X_train)
            val_pred = self.predict(X_val)
            
            train_loss = self.calculate_loss(y_train, train_pred)
            val_loss = self.calculate_loss(y_val, val_pred)
            
            train_acc = np.mean(np.argmax(train_pred, axis=1) == np.argmax(y_train, axis=1))
            val_acc = np.mean(np.argmax(val_pred, axis=1) == np.argmax(y_val, axis=1))
            
            history['train_loss'].append(train_loss)
            history['train_accuracy'].append(train_acc)
            history['val_loss'].append(val_loss)
            history['val_accuracy'].append(val_acc)
        
        return history
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Make predictions"""
        return self.forward_propagation(X)[-1]
    
    def calculate_loss(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calculate cross-entropy loss with numerical stability"""
        epsilon = 1e-15
        y_pred = np.clip(y_pred, epsilon, 1 - epsilon)
        return -np.mean(np.sum(y_true * np.log(y_pred), axis=1))
    
    def save_model(self, path: str):
        """Save model parameters and architecture"""
        model_data = {
            'layers': self.layers,
            'learning_rate': self.learning_rate,
            'weights': [w.tolist() for w in self.weights],
            'biases': [b.tolist() for b in self.biases],
            'history': self.history
        }
        
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump(model_data, path)
    
    def load_model(self, path: str):
        """Load model parameters and architecture"""
        model_data = joblib.load(path)
        
        self.layers = model_data['layers']
        self.learning_rate = model_data['learning_rate']
        self.weights = [np.array(w) for w in model_data['weights']]
        self.biases = [np.array(b) for b in model_data['biases']]
        self.history = model_data['history']