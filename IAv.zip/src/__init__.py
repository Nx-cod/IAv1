"""
Advanced Chatbot Project
A sophisticated chatbot implementation using neural networks and natural language processing.
"""

from .advanced_chatbot import AdvancedChatbot
from .neural_network import NeuralNetwork
from .data_processor import DataProcessor
from .training_manager import TrainingManager

__version__ = '1.0.0'