import numpy as np
from .neural_network import NeuralNetwork
from .data_processor import DataProcessor

class AdvancedChatbot:
    def __init__(self, model_path=None):
        self.neural_network = NeuralNetwork()
        self.data_processor = DataProcessor()
        self.model_path = model_path
        self.context = {}
        
    def initialize(self):
        """Initialize the chatbot and load pre-trained model if available"""
        if self.model_path:
            self.neural_network.load_model(self.model_path)
        self.data_processor.load_knowledge_base()
        
    def process_input(self, user_input: str) -> str:
        """Process user input and generate response"""
        processed_input = self.data_processor.preprocess_text(user_input)
        input_vector = self.data_processor.vectorize_text(processed_input)
        
        # Get prediction from neural network
        prediction = self.neural_network.predict(input_vector)
        
        # Generate response based on prediction
        response = self.generate_response(prediction)
        
        return response
    
    def generate_response(self, prediction) -> str:
        """Generate appropriate response based on neural network prediction"""
        response_templates = self.data_processor.get_response_templates()
        
        # Select best matching response template
        best_match = np.argmax(prediction)
        response = response_templates[best_match]
        
        # Apply context-aware modifications
        response = self.apply_context(response)
        
        return response
    
    def apply_context(self, response: str) -> str:
        """Apply contextual information to response"""
        for key, value in self.context.items():
            response = response.replace(f"{{{key}}}", str(value))
        return response
    
    def update_context(self, new_context: dict):
        """Update conversation context"""
        self.context.update(new_context)
        
    def train(self, training_data, epochs=100):
        """Train the chatbot with new data"""
        processed_data = self.data_processor.prepare_training_data(training_data)
        self.neural_network.train(processed_data, epochs=epochs)
        
    def save_model(self, path: str):
        """Save the trained model"""
        self.neural_network.save_model(path)