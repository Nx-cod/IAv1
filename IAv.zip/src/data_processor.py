import numpy as np
import pandas as pd
import spacy
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from unidecode import unidecode
import json
from typing import List, Dict, Tuple
import os

class AdvancedDataProcessor:
    def __init__(self):
        # Download required NLTK data
        nltk.download('punkt')
        nltk.download('stopwords')
        nltk.download('wordnet')
        
        # Load spaCy model
        self.nlp = spacy.load('en_core_web_sm')
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))
        
        # Initialize vocabulary and embeddings
        self.vocab = {}
        self.reverse_vocab = {}
        self.word_embeddings = {}
        self.max_sequence_length = 50
        
    def preprocess_text(self, text: str) -> str:
        """Advanced text preprocessing"""
        # Normalize text
        text = unidecode(text.lower().strip())
        
        # Tokenize using spaCy
        doc = self.nlp(text)
        
        # Advanced token processing
        tokens = []
        for token in doc:
            if (not token.is_stop and 
                not token.is_punct and 
                not token.is_space and 
                len(token.text) > 1):
                
                # Lemmatization
                lemma = self.lemmatizer.lemmatize(token.text)
                tokens.append(lemma)
        
        return ' '.join(tokens)
    
    def build_vocabulary(self, texts: List[str], min_freq: int = 2):
        """Build vocabulary from texts with frequency threshold"""
        word_freq = {}
        
        # Count word frequencies
        for text in texts:
            words = self.preprocess_text(text).split()
            for word in words:
                word_freq[word] = word_freq.get(word, 0) + 1
        
        # Build vocabulary with frequency threshold
        vocab = ['<PAD>', '<UNK>']
        for word, freq in word_freq.items():
            if freq >= min_freq:
                vocab.append(word)
        
        # Create word to index mapping
        self.vocab = {word: idx for idx, word in enumerate(vocab)}
        self.reverse_vocab = {idx: word for word, idx in self.vocab.items()}
        
        # Initialize word embeddings
        embedding_dim = 100
        self.word_embeddings = {
            word: np.random.uniform(-0.1, 0.1, embedding_dim)
            for word in self.vocab
        }
    
    def text_to_sequence(self, text: str) -> np.ndarray:
        """Convert text to sequence of word indices"""
        words = self.preprocess_text(text).split()
        sequence = []
        
        for word in words[:self.max_sequence_length]:
            idx = self.vocab.get(word, self.vocab['<UNK>'])
            sequence.append(idx)
        
        # Pad sequence
        while len(sequence) < self.max_sequence_length:
            sequence.append(self.vocab['<PAD>'])
        
        return np.array(sequence)
    
    def sequence_to_embeddings(self, sequence: np.ndarray) -> np.ndarray:
        """Convert sequence to word embeddings"""
        embeddings = []
        for idx in sequence:
            word = self.reverse_vocab[idx]
            embedding = self.word_embeddings[word]
            embeddings.append(embedding)
        return np.array(embeddings)
    
    def prepare_training_data(self, data: List[Tuple[str, int]], num_classes: int) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare data for training"""
        X = []
        y = []
        
        for text, label in data:
            # Convert text to sequence and then to embeddings
            sequence = self.text_to_sequence(text)
            embeddings = self.sequence_to_embeddings(sequence)
            
            # Flatten embeddings
            X.append(embeddings.flatten())
            
            # One-hot encode labels
            label_one_hot = np.zeros(num_classes)
            label_one_hot[label] = 1
            y.append(label_one_hot)
        
        return np.array(X), np.array(y)
    
    def save_processor_state(self, path: str):
        """Save processor state"""
        state = {
            'vocab': self.vocab,
            'reverse_vocab': self.reverse_vocab,
            'word_embeddings': {k: v.tolist() for k, v in self.word_embeddings.items()},
            'max_sequence_length': self.max_sequence_length
        }
        
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            json.dump(state, f)
    
    def load_processor_state(self, path: str):
        """Load processor state"""
        with open(path, 'r') as f:
            state = json.load(f)
        
        self.vocab = state['vocab']
        self.reverse_vocab = state['reverse_vocab']
        self.word_embeddings = {k: np.array(v) for k, v in state['word_embeddings'].items()}
        self.max_sequence_length = state['max_sequence_length']