from typing import List, Tuple
import numpy as np
from .data_processor import DataProcessor
from .neural_network import NeuralNetwork

class TrainingManager:
    def __init__(self, chatbot):
        self.chatbot = chatbot
        self.training_history = []
        
    def prepare_training_batch(self, data: List[Tuple[str, int]]):
        """Prepare a batch of training data"""
        return self.chatbot.data_processor.prepare_training_data(data)
    
    def train_model(self, training_data: List[Tuple[str, int]], epochs: int = 100):
        """Train the model with new data"""
        X_train, y_train = self.prepare_training_batch(training_data)
        
        history = self.chatbot.neural_network.train(
            (X_train, y_train),
            epochs=epochs
        )
        
        self.training_history.append({
            'epochs': epochs,
            'accuracy': history.history['accuracy'][-1],
            'loss': history.history['loss'][-1]
        })
        
    def evaluate_model(self, test_data: List[Tuple[str, int]]):
        """Evaluate model performance"""
        X_test, y_test = self.prepare_training_batch(test_data)
        
        predictions = self.chatbot.neural_network.predict(X_test)
        accuracy = np.mean(np.argmax(predictions, axis=1) == y_test)
        
        return {
            'accuracy': accuracy,
            'total_samples': len(test_data)
        }
        
    def get_training_history(self):
        """Get training history"""
        return self.training_history