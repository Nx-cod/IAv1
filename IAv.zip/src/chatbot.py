import numpy as np
import json
import os
from typing import Dict, List, Tuple
from .neural_network import CustomNeuralNetwork
from .data_processor import AdvancedDataProcessor

class AdvancedChatbot:
    def __init__(self, model_path: str = None):
        # Initialize components
        self.data_processor = AdvancedDataProcessor()
        self.neural_network = None
        self.context = {}
        self.conversation_history = []
        self.knowledge_base = {}
        self.response_templates = {}
        
        # Load existing model if provided
        if model_path and os.path.exists(model_path):
            self.load_model(model_path)
    
    def initialize(self, num_classes: int):
        """Initialize neural network"""
        # Define network architecture
        input_size = self.data_processor.max_sequence_length * 100  # embedding_dim = 100
        layers = [
            input_size,    # Input layer
            512,          # First hidden layer
            256,          # Second hidden layer
            128,          # Third hidden layer
            num_classes   # Output layer
        ]
        
        self.neural_network = CustomNeuralNetwork(layers, learning_rate=0.001)
    
    def load_knowledge_base(self, path: str):
        """Load knowledge base and response templates"""
        with open(path, 'r') as f:
            data = json.load(f)
            self.knowledge_base = data.get('knowledge_base', {})
            self.response_templates = data.get('responses', {})
    
    def save_knowledge_base(self, path: str):
        """Save knowledge base and response templates"""
        data = {
            'knowledge_base': self.knowledge_base,
            'responses': self.response_templates
        }
        
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def process_input(self, user_input: str) -> str:
        """Process user input and generate response"""
        # Preprocess input
        processed_input = self.data_processor.preprocess_text(user_input)
        
        # Convert to embeddings
        sequence = self.data_processor.text_to_sequence(processed_input)
        embeddings = self.data_processor.sequence_to_embeddings(sequence)
        
        # Get prediction
        prediction = self.neural_network.predict(embeddings.reshape(1, -1))
        
        # Generate response
        response = self.generate_response(prediction[0])
        
        # Update conversation history
        self.conversation_history.append({
            'user_input': user_input,
            'processed_input': processed_input,
            'response': response,
            'context': self.context.copy()
        })
        
        return response
    
    def generate_response(self, prediction: np.ndarray) -> str:
        """Generate response based on prediction and context"""
        # Get best matching intent
        intent_idx = np.argmax(prediction)
        confidence = prediction[intent_idx]
        
        # Get response template
        if confidence > 0.5:
            response_category = list(self.response_templates.keys())[intent_idx]
            responses = self.response_templates[response_category]
            response = np.random.choice(responses)
        else:
            response = "I'm not sure I understand. Could you please rephrase that?"
        
        # Apply context
        response = self.apply_context(response)
        
        return response
    
    def apply_context(self, response: str) -> str:
        """Apply context to response template"""
        for key, value in self.context.items():
            placeholder = f"{{{key}}}"
            if placeholder in response:
                response = response.replace(placeholder, str(value))
        return response
    
    def update_context(self, new_context: Dict):
        """Update conversation context"""
        self.context.update(new_context)
    
    def train(self, training_data: List[Tuple[str, int]], epochs: int = 100, batch_size: int = 32):
        """Train the chatbot"""
        # Prepare training data
        X, y = self.data_processor.prepare_training_data(training_data, len(self.response_templates))
        
        # Train neural network
        history = self.neural_network.train(X, y, epochs=epochs, batch_size=batch_size)
        
        return history
    
    def save_model(self, path: str):
        """Save model and processor state"""
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        # Save neural network
        self.neural_network.save_model(f"{path}_network.joblib")
        
        # Save data processor
        self.data_processor.save_processor_state(f"{path}_processor.json")
        
        # Save conversation history
        with open(f"{path}_history.json", 'w') as f:
            json.dump(self.conversation_history, f, indent=2)
    
    def load_model(self, path: str):
        """Load model and processor state"""
        # Load neural network
        self.neural_network = CustomNeuralNetwork([])  # Temporary initialization
        self.neural_network.load_model(f"{path}_network.joblib")
        
        # Load data processor
        self.data_processor.load_processor_state(f"{path}_processor.json")
        
        # Load conversation history
        if os.path.exists(f"{path}_history.json"):
            with open(f"{path}_history.json", 'r') as f:
                self.conversation_history = json.load(f)