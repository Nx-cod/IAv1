from src.chatbot import AdvancedChatbot
import json
import os

def main():
    # Initialize chatbot
    chatbot = AdvancedChatbot()
    
    # Load knowledge base
    knowledge_base_path = 'data/knowledge_base.json'
    chatbot.load_knowledge_base(knowledge_base_path)
    
    # Initialize neural network
    num_classes = len(chatbot.response_templates)
    chatbot.initialize(num_classes)
    
    # Example training data
    training_data = [
        ("Hello there", 0),
        ("Hi, how are you?", 0),
        ("Good morning", 0),
        ("Goodbye", 1),
        ("Bye", 1),
        ("See you later", 1),
        ("What's the weather like?", 2),
        ("How does this work?", 2),
        ("Tell me more", 2)
    ]
    
    # Train the model
    print("Training the chatbot...")
    history = chatbot.train(training_data, epochs=50, batch_size=4)
    
    # Save the trained model
    print("Saving the model...")
    os.makedirs('models', exist_ok=True)
    chatbot.save_model('models/chatbot_model')
    
    # Interactive chat loop
    print("\nChatbot is ready! Type 'quit' to exit.")
    while True:
        user_input = input("\nYou: ")
        if user_input.lower() == 'quit':
            break
        
        response = chatbot.process_input(user_input)
        print(f"Bot: {response}")
    
    # Save final state
    chatbot.save_model('models/chatbot_model')
    print("\nFinal model state saved. Goodbye!")

if __name__ == "__main__":
    main()