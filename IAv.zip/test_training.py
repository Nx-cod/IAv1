import unittest
import numpy as np
from src.advanced_chatbot import AdvancedChatbot
from src.training_manager import TrainingManager

class TestChatbotTraining(unittest.TestCase):
    def setUp(self):
        self.chatbot = AdvancedChatbot()
        self.training_manager = TrainingManager(self.chatbot)
        
    def test_training_data_preparation(self):
        training_data = [
            ("Hello", 0),
            ("Hi there", 0),
            ("Goodbye", 1)
        ]
        
        X, y = self.training_manager.prepare_training_batch(training_data)
        
        self.assertEqual(X.shape[0], 3)  # 3 training examples
        self.assertEqual(y.shape[0], 3)  # 3 labels
        
    def test_model_training(self):
        training_data = [
            ("Hello", 0),
            ("Hi there", 0),
            ("Goodbye", 1)
        ]
        
        self.training_manager.train_model(training_data, epochs=10)
        history = self.training_manager.get_training_history()
        
        self.assertEqual(len(history), 1)
        self.assertIn('accuracy', history[0])
        self.assertIn('loss', history[0])
        
    def test_model_evaluation(self):
        # Train the model first
        training_data = [
            ("Hello", 0),
            ("Hi there", 0),
            ("Goodbye", 1)
        ]
        self.training_manager.train_model(training_data, epochs=10)
        
        # Evaluate
        test_data = [
            ("Hey", 0),
            ("Bye", 1)
        ]
        evaluation = self.training_manager.evaluate_model(test_data)
        
        self.assertIn('accuracy', evaluation)
        self.assertIn('total_samples', evaluation)
        self.assertEqual(evaluation['total_samples'], 2)

if __name__ == '__main__':
    unittest.main()