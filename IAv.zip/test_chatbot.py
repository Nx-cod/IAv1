import unittest
import numpy as np
import os
from src.chatbot import AdvancedChatbot
from src.neural_network import CustomNeuralNetwork
from src.data_processor import AdvancedDataProcessor

class TestAdvancedChatbot(unittest.TestCase):
    def setUp(self):
        self.chatbot = AdvancedChatbot()
        self.chatbot.load_knowledge_base('data/knowledge_base.json')
        self.chatbot.initialize(num_classes=3)
        
        self.training_data = [
            ("Hello there", 0),
            ("Hi, how are you?", 0),
            ("Goodbye", 1),
            ("What's up?", 2)
        ]
    
    def test_initialization(self):
        self.assertIsNotNone(self.chatbot.neural_network)
        self.assertIsNotNone(self.chatbot.data_processor)
        self.assertIsInstance(self.chatbot.context, dict)
    
    def test_preprocessing(self):
        text = "Hello, how are you doing today?"
        processed = self.chatbot.data_processor.preprocess_text(text)
        self.assertIsInstance(processed, str)
        self.assertTrue(len(processed) > 0)
    
    def test_training(self):
        history = self.chatbot.train(self.training_data, epochs=5, batch_size=2)
        self.assertIn('train_loss', history)
        self.assertIn('train_accuracy', history)
        self.assertIn('val_loss', history)
        self.assertIn('val_accuracy', history)
    
    def test_response_generation(self):
        # Train the model first
        self.chatbot.train(self.training_data, epochs=5, batch_size=2)
        
        # Test response generation
        response = self.chatbot.process_input("Hello")
        self.assertIsInstance(response, str)
        self.assertTrue(len(response) > 0)
    
    def test_context_handling(self):
        context = {"name": "John", "time": "morning"}
        self.chatbot.update_context(context)
        self.assertEqual(self.chatbot.context["name"], "John")
        self.assertEqual(self.chatbot.context["time"], "morning")
    
    def test_model_saving_loading(self):
        # Train and save
        self.chatbot.train(self.training_data, epochs=5, batch_size=2)
        self.chatbot.save_model('models/test_model')
        
        # Load and verify
        new_chatbot = AdvancedChatbot('models/test_model')
        new_chatbot.initialize(num_classes=3)
        
        # Test both chatbots with same input
        original_response = self.chatbot.process_input("Hello")
        loaded_response = new_chatbot.process_input("Hello")
        
        self.assertIsInstance(original_response, str)
        self.assertIsInstance(loaded_response, str)
    
    def test_conversation_history(self):
        self.chatbot.process_input("Hello")
        self.chatbot.process_input("How are you?")
        
        self.assertEqual(len(self.chatbot.conversation_history), 2)
        self.assertIn('user_input', self.chatbot.conversation_history[0])
        self.assertIn('response', self.chatbot.conversation_history[0])
    
    def tearDown(self):
        # Clean up test files
        if os.path.exists('models/test_model_network.joblib'):
            os.remove('models/test_model_network.joblib')
        if os.path.exists('models/test_model_processor.json'):
            os.remove('models/test_model_processor.json')
        if os.path.exists('models/test_model_history.json'):
            os.remove('models/test_model_history.json')

if __name__ == '__main__':
    unittest.main()